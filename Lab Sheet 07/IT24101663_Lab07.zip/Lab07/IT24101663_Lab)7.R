setwd("C:\\Users\\USER\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\SLIIT CAMPUS\\Year_2_Semester_1\\PS\\Labs\\Lab07")

#Question01
#Part01
#P(x<=10)???
punif(10,min =0, max = 30, lower.tail = TRUE)

#part02
#p(x>20) = 1 - p(x<=20)
1-punif(20,min = 0,max = 30, lower.tail = TRUE)
#or
punif(20,min = 0,max = 30, lower.tail = FALSE)

#Question02
#part01
#p(x<=3)=??, lambda =0.5
pexp(3,rate = 0.5, lower.tail = TRUE)

#part02
#p(x>4) = 1 - p(x<=4)
pexp(4,rate = 0.5, lower.tail = FALSE)

#part03
#p(2<x<4) = p(x<=4) -p(X<=2)
pexp(4,rate = 0.5, lower.tail = TRUE) - pexp(2,rate = 0.5, lower.tail = TRUE)

#Question03
#part01
#p(x>=37.9) = 1 - p(x<37.9)
1 - pnorm(37.9, mean = 36.8, sd = 0.4, lower.tail = TRUE)

#part02
#p(36.4<x<36.9) = p(x<=36.9) - p(x<=36.4)
pnorm(36.9, mean = 36.8, sd = 0.4, lower.tail = TRUE) - pnorm(36.4, mean = 36.8, sd = 0.4, lower.tail = TRUE)

#part03
#find Temperature is 'b' 
#p(x<b) = 1.2% = 0.012
qnorm(0.012, mean = 36.8, sd = 0.4, lower.tail = TRUE)

#part04
#find temperature is 'a'
#p(x<b) = 1.0% = 0.01
qnorm(0.01, mean = 36.8, sd = 0.4, lower.tail = FALSE)

#Exercise
#part 01
#p(10<x<25) = p(x<=25) - p(x>=10)
punif(25,min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

#part 02
# lambda = 0.0.333, p(x<=2)
pexp(2, rate = 0.333, lower.tail = TRUE)

#part03
#Q1
#p(x>130), mean = 100, sd = 15
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

#Q2
#p(x<=b) = 0.95
qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)
