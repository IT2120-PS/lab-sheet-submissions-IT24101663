setwd("C:\\Users\\IT24101663\\Desktop\\Lab04")
mlb <- read.table("DATA 4.txt", header = TRUE)
str(mlb) 
branch_data <- read.csv("Exercise.txt")
str(branch_data)

boxplot(mlb$X1, main="Boxplot for team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(mlb$X2, main="boxplot for team Salary",  outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(mlb$X3, main="boxplot for Years",  outline = TRUE, outpch = 8, horizontal = TRUE)

# Histograms
hist(mlb$X1, main="Histrogram for team Attendance", xlab="Attendance", ylab = "Frequency")
hist(mlb$X2, main="Histrogram for team Salary", xlab="Salary", ylab = "Frequency")
hist(mlb$X3, main="Histrogram for Years", xlab="Years", ylab = "Frequency")

# Stem-and-leaf
stem(mlb$X1)
stem(mlb$X2)
stem(mlb$X3)

# Mean, Median, SD, Quartiles, IQR
s <- function(x) list(mean=mean(x), median=median(x), sd=sd(x),
                      Q1=quantile(x, .25, type=2),
                      Q3=quantile(x, .75, type=2),
                      IQR=IQR(x))
s(mlb$X1); s(mlb$X2); s(mlb$X3)


modes <- function(x) {
  ux <- unique(x)
  tab <- tabulate(match(x, ux))
  ux[tab == max(tab)]
}
modes(mlb$X3) 


iqr_outliers <- function(x) {
  q1 <- quantile(x, 0.25, type=2); q3 <- quantile(x, 0.75, type=2)
  i <- IQR(x); lower <- q1 - 1.5*i; upper <- q3 + 1.5*i
  list(bounds=c(lower=lower, upper=upper), outliers=x[x<lower | x>upper])
}
iqr_outliers(mlb$X1)
iqr_outliers(mlb$X2)
iqr_outliers(mlb$X3) 

branch_data <- read.csv("Exercise.txt")

boxplot(branch_data$Sales_X1, main="Sales (X1)")
fivenum(branch_data$Advertising_X2) 
IQR(branch_data$Advertising_X2)

iqr_outliers <- function(x) {
  q1 <- quantile(x, 0.25, type=2); q3 <- quantile(x, 0.75, type=2)
  i <- IQR(x); lower <- q1 - 1.5*i; upper <- q3 + 1.5*i
  list(bounds=c(lower=lower, upper=upper), outliers=x[x<lower | x>upper])
}
iqr_outliers(branch_data$Years_X3)

