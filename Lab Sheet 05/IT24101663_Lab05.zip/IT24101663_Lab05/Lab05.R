setwd("C:\\Users\\IT24101663\\Desktop\\IT24101663_Lab05")
data<- read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)

#part01
names(data)<-c("X1","X2")
attach(data)
hist(X2,main="Histogram for NUmber of Shareholders")

#part02
histogram<- hist(X2,main="Histogram forNumber of shareholders",breaks = seq(130,270,length = 8,right = FALSE))
?hist

#part03
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i] <- paste0("[",breaks[i],",", breaks[i+1], ")")
}

cbind(classes = classes, frequency = freq)


#part04
lines(mids, freq)
plot(mids, freq, type = 'l', main = "Frequency polygon for Shareholders",xlab = "Shareholders",ylab = "Frequency",ylim = c(0,max(freq)))

#part05
cum.freq <- cumsum(freq)
new <- c()
for(i in 1:length(breaks)){
  if(i == 1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

## Draw cumulative frequency polygon in a new plot
plot(breaks, new, type = 'l',
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

## Obtain upper limit of each class along with its cumulative frequency in a table
cbind(Upper = breaks, CumFreq = new)


#Exercises

## 1. Import the dataset
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Check the data
head(DeliveryTimes)
str(DeliveryTimes)

##2
DeliveryTimes$DeliveryTime <- as.numeric(as.character(DeliveryTimes$DeliveryTime))
# Set breaks for 9 intervals between 20 and 70
breaks <- seq(20, 70, length.out = 10)

# Draw histogram
hist(DeliveryTimes$Delivery_Time_.minutes.,
     breaks = breaks,
     right = FALSE,  # right-open intervals
     main = "Histogram of Delivery Times",
     xlab = "Delivery Times (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")


##part 4
# Compute frequency for each class
freq <- hist(DeliveryTimes$Delivery_Time_.minutes., 
             breaks = breaks, plot = FALSE)$counts

# Compute cumulative frequency
cum.freq <- cumsum(freq)

# Create points for ogive (include 0 at the start)
cum.freq.points <- c(0, cum.freq)
breaks.points <- breaks  # breaks already has one extra for right-open intervals

# Plot ogive
plot(breaks.points, cum.freq.points,
     type = "b",  # points connected with lines
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Times (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue",
     pch = 19)
